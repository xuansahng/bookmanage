package com.servlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/SecondServlet")
public class SecondServlet extends HttpServlet{

	public void init(ServletConfig config) throws ServletException{
		super.init(config);
	}
	@Override
	public void destroy() {
		super.destroy();
	}

	public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String name=request.getParameter("userName");
		String pass=request.getParameter("pwd");
		if(name.equals("admin") & pass.equals("123")){
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("sucess.jsp");
			requestDispatcher.forward(request,response);

		}

	}
}
