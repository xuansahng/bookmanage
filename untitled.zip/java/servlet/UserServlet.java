package servlet;

import bean.Book;
import bean.User;
import service.BookService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import static java.lang.System.out;

@WebServlet(name="UserServlet",urlPatterns = "/UserServlet")
public class UserServlet extends HttpServlet {

    UserService us = new UserService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String methodName = request.getParameter("method");
        try {
            Method method = getClass().getMethod(methodName, HttpServletRequest.class, HttpServletResponse.class);
            method.invoke(this, request, response);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            // ������������쳣
        }
    }

    public void deleteUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ����ɾ��ͼ����߼�
        // ...
        int userId = Integer.parseInt(request.getParameter("id"));
        int page = Integer.parseInt(request.getParameter("page"));
        us.deleteUser(userId);
        response.sendRedirect("/like/UserServlet?method=selectAllUser&page="+page);
    }
    private boolean isUserIdExists(String name) {
        if(us.findUser(name)==null)
            return false;
        else
            return true;
    }

    public void insertUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String name = request.getParameter("user");
        String password = request.getParameter("rpassword");
        String email = request.getParameter("email");
        String isregister = request.getParameter("isRegister");
        if(isregister==null){
            isregister="0";
        }
        out.println(name+password+email+isregister);

        if (isUserIdExists(name)) {
            // ���ID�Ѵ��ڣ������ڴ˴������ظ�ID�������������ʾ������Ϣ����ת�ر���ҳ��
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('���˺��Ѵ��ڣ�����������˺����ơ�');");
            out.println("window.location.href='/like/bigwork/adduser.jsp';"); // �ض����ʵ���ҳ��
            out.println("</script>");
        }else if(isregister.equals("1")){
            User user = new User();
            user.setUserName(name);
            user.setPassword(password);
            user.setEmail(email);
            us.addUser(user);
            response.sendRedirect("/like/bigwork/login.jsp");
        }else{
            // ���� User������������ֵ
            User user = new User();
            user.setUserName(name);
            user.setPassword(password);
            user.setEmail(email);
            us.addUser(user);
            response.sendRedirect("/like/UserServlet?method=selectAllUser");
        }
    }

    public void selectAllUser(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
        // ������ѯ����ͼ����߼�
        // ...
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        List<User> list = us.getAllUsers();
        request.getSession().setAttribute("AllUserList", list);
        try{
            int page = Integer.parseInt(request.getParameter("page"));
            response.sendRedirect("bigwork/showuser.jsp?page="+page);
        }catch (Exception e){
            response.sendRedirect("bigwork/showuser.jsp");
        }
    }

    public void selectUserById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // ��������ID��ѯͼ����߼�
        // ...
    }

    public void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // ��������ͼ����߼�
        // ...
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        int page = Integer.parseInt(request.getParameter("page"));
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("user");
        String password = request.getParameter("rpassword");
        String email = request.getParameter("email");
        User user = new User();
        user.setUserId(id);
        user.setUserName(name);
        user.setPassword(password);
        user.setEmail(email);
        us.updateUser(user);
        response.sendRedirect("/like/UserServlet?method=selectAllUser&page="+page);
    }
    public void updateUserGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ��������ͼ����߼�
        // ...
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        int userId = Integer.parseInt(request.getParameter("id"));
        int page = Integer.parseInt(request.getParameter("page"));
        User before = us.findUser(userId);
        request.getSession().setAttribute("u_before", before);
        request.getSession().setAttribute("u_pa",page);
        response.sendRedirect("bigwork/editUser.jsp");
    }
}
