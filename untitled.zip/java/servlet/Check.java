package servlet;

import service.BookService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.*;

import static java.lang.System.out;

@WebServlet(name="Check",urlPatterns = "/Check")
public class Check extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String user = request.getParameter("user");
        String password = request.getParameter("password");

        String jdbcUrl = "jdbc:mysql://localhost:3306/book";
        String dbUsername = "root";
        String dbPassword = "123456";

        try {
            // ��������
            Class.forName("com.mysql.cj.jdbc.Driver");

            // �������ݿ�����
            Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);

            // ������ѯ���
            String query = "SELECT * FROM users WHERE name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, user);

            // ִ�в�ѯ
            ResultSet resultSet = statement.executeQuery();

            String UserName = null;
            if (resultSet.next()) {
                UserName = resultSet.getString("name");
                String Password = resultSet.getString("password");

                if (UserName.equals(user) && Password.equals(password)) {
                    // ��¼�ɹ�
                    String encodedUserName = URLEncoder.encode(UserName, "UTF-8");
                    String redirectURL = "/like/bigwork/welcome.jsp?UserName=" + encodedUserName;
                    String encodedURL = response.encodeRedirectURL(redirectURL);
                    request.getSession().setAttribute("user", encodedUserName);
                    response.sendRedirect(encodedURL);
                } else {
                    // ��¼ʧ��
                    response.sendRedirect("/like/bigwork/login.jsp?ErrorCode=404");
                }
            } else {
                // �û������ڻ��������
                response.sendRedirect("/like/bigwork/login.jsp?ErrorCode=408");
            }
            // �ر����ݿ�����
            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
