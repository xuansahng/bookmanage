package servlet;


import bean.Book;
import bean.Cart;
import bean.CartItem;
import bean.User;
import service.BookService;
import service.CartService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static java.lang.System.out;

@WebServlet(name="CartItemServlet",urlPatterns = "/CartItemServlet")
public class CartItemServlet extends HttpServlet {

    CartService cs = new CartService();
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }
    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodName = request.getParameter("method");
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        try {
            Method method = getClass().getMethod(methodName, HttpServletRequest.class, HttpServletResponse.class);
            method.invoke(this, request, response);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            // ������������쳣
        }
    }

    private boolean isCartIdExists(int id) {
        if(cs.findCart(id)==null)
            return false;
        else
            return true;
    }
    public void insertCartItem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        Random random = new Random();
        int min = 10000; // ��Сֵ��5λ������Сֵ��
        int max = 99999; // ���ֵ��5λ�������ֵ��

        int randomNumber = random.nextInt(max - min + 1) + min;
        int id = Integer.parseInt(request.getParameter("id"));
        int sl = Integer.parseInt(request.getParameter("count"));

        Double tp = sl*Double.parseDouble(request.getParameter("price"));

        while(isCartIdExists(randomNumber)) {
            // ���ID�Ѵ��ڣ������ڴ˴������ظ�ID�������������ʾ������Ϣ����ת�ر���ҳ��
            randomNumber = random.nextInt(max - min + 1) + min;
        }
            // ���� Book ������������ֵ
        HttpSession session = httpRequest.getSession();
        UserService us = new UserService();
        String userName = URLDecoder.decode((String) session.getAttribute("user"), "UTF-8");
        User user = us.findUser(userName);
        out.print((String) session.getAttribute("user"));
        out.print(user.getUserId());
        CartItem ci = new CartItem(sl,randomNumber,id,tp);
        Cart ct = new Cart(randomNumber,sl,user.getUserId(),tp);
        cs.addCartItem(ci);
        cs.addCart(ct);
        response.sendRedirect("/like/BookServlet?method=selectAllBook");
    }
    public void selectAllCart(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
        // ������ѯ����ͼ����߼�
        // ...
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        CartService cs = new CartService();
        BookService bs = new BookService();
        List<Cart> list = cs.getAllCarts();

        for (int i = 0; i < list.size(); i++) {
            Cart cart = list.get(i);
            List<CartItem> li = cs.getAllCartItems(cart.getCart_id());
            List<String> name = new ArrayList<>();
            List<Integer> count = new ArrayList<>();
            List<Double> tp = new ArrayList<>();

            for (CartItem cartItem : li) {
                name.add(bs.findBook(cartItem.getBook_id()).getBookName());
                count.add(cartItem.getQuantity());
                tp.add(cartItem.getTotal_price());
            }
            cart.setBook_name(name);
            cart.setBook_count(count);
            cart.setBook_tp(tp);
            list.set(i, cart);  // �����޸ĺ�� cart ����

            out.println("ada" + count.get(0));
        }

        request.getSession().setAttribute("AllCartList", list);

        try{
            int page = Integer.parseInt(request.getParameter("page"));
            response.sendRedirect("bigwork/showcart.jsp?bookpage="+page);
        }catch (Exception e){
            response.sendRedirect("bigwork/showcart.jsp");
        }
    }
}
