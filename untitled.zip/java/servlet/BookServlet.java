package servlet;

import bean.Book;
import service.BookService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

@WebServlet(name="BookServlet",urlPatterns = "/BookServlet")
public class BookServlet extends HttpServlet {

    BookService bs = new BookService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodName = request.getParameter("method");
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        try {
            Method method = getClass().getMethod(methodName, HttpServletRequest.class, HttpServletResponse.class);
            method.invoke(this, request, response);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            // ������������쳣
        }
    }

    public void deleteBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ����ɾ��ͼ����߼�
        // ...
        int bookId = Integer.parseInt(request.getParameter("id"));
        int page = Integer.parseInt(request.getParameter("page"));
        bs.deleteBook(bookId);
        response.sendRedirect("/like/BookServlet?method=selectAllBook&page="+page);
    }
    private boolean isBookIdExists(int id) {
        if(bs.findBook(id)==null)
            return false;
        else
            return true;
    }

    public void insertBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String encodeauthor = request.getParameter("author");
        String author = java.net.URLDecoder.decode(encodeauthor, "UTF-8");
        int sales = Integer.parseInt(request.getParameter("sales"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        String imgPath = request.getParameter("imgPath");

        if (isBookIdExists(id)) {
            // ���ID�Ѵ��ڣ������ڴ˴������ظ�ID�������������ʾ������Ϣ����ת�ر���ҳ��
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('���鱾 ID �Ѵ��ڣ����������� ID��');");
            out.println("window.location.href='/like/bigwork/addbook.jsp';"); // �ض����ʵ���ҳ��
            out.println("</script>");
        }else{
            // ���� Book ������������ֵ
            Book book = new Book();
            book.setBookId(id);
            book.setBookName(name);
            book.setPrice(price);
            book.setAuthor(author);
            book.setPublish(sales);
            book.setInventory(stock);
            book.setPhotoPath(imgPath);
            bs.addBook(book);
            response.sendRedirect("/like/BookServlet?method=selectAllBook");
        }
    }

    public void selectAllBook(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
        // ������ѯ����ͼ����߼�
        // ...
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        BookService bs = new BookService();
        List<Book> list = bs.getAllBooks();
        request.getSession().setAttribute("AllBookList", list);
        try{
            int page = Integer.parseInt(request.getParameter("page"));
            response.sendRedirect("bigwork/showbook.jsp?page="+page);
        }catch (Exception e){
            response.sendRedirect("bigwork/showbook.jsp");
        }
    }

    public void selectBookById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // ��������ID��ѯͼ����߼�
        // ...
    }

    public void updateBook(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // ��������ͼ����߼�
        // ...
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        int page = Integer.parseInt(request.getParameter("page"));
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String author = request.getParameter("author");
        int sales = Integer.parseInt(request.getParameter("sales"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        String imgPath = request.getParameter("imgPath");
        Book book = new Book();
        book.setBookId(id);
        book.setBookName(name);
        book.setPrice(price);
        book.setAuthor(author);
        book.setPublish(sales);
        book.setInventory(stock);
        book.setPhotoPath(imgPath);
        bs.updateBook(book);
        response.sendRedirect("/like/BookServlet?method=selectAllBook&page="+page);
    }
    public void updateBookGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ��������ͼ����߼�
        // ...
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        int bookId = Integer.parseInt(request.getParameter("id"));
        int page = Integer.parseInt(request.getParameter("page"));
        Book before = bs.findBook(bookId);
        request.getSession().setAttribute("before", before);
        request.getSession().setAttribute("pa",page);
        response.sendRedirect("bigwork/edit.jsp");
    }

    public void searchBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        BookService bs = new BookService();
        List<Book> list;
        list = bs.getAllBooks();
        request.getSession().setAttribute("AllBookList", list);
        response.sendRedirect("bigwork/showbook.jsp");
    }
    public void cartBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        int bookId = Integer.parseInt(request.getParameter("id"));
        int page = Integer.parseInt(request.getParameter("page"));
        Book cart = bs.findBook(bookId);
        request.getSession().setAttribute("cart", cart);
        request.getSession().setAttribute("pa",page);
        response.sendRedirect("bigwork/incart.jsp");
    }
    public void buyBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        int bookId = Integer.parseInt(request.getParameter("id"));
        int page = Integer.parseInt(request.getParameter("page"));
        Book buy = bs.findBook(bookId);
        request.getSession().setAttribute("buy", buy);
        request.getSession().setAttribute("pa",page);
    }
}
