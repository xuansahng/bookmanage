package servlet;


import bean.*;
import service.BookService;
import service.CartService;
import service.OrderService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.util.List;
import java.util.Random;

import static java.lang.System.out;

@WebServlet(name="OrderItemServlet",urlPatterns = "/OrderItemServlet")
public class OrderItemServlet extends HttpServlet {

    OrderService os = new OrderService();
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        handleRequest(request, response);
    }
    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodName = request.getParameter("method");
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        try {
            Method method = getClass().getMethod(methodName, HttpServletRequest.class, HttpServletResponse.class);
            method.invoke(this, request, response);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            // ������������쳣
        }
    }

    private boolean isOrderIdExists(int id) {
        if(os.findOrder(id)==null)
            return false;
        else
            return true;
    }
    public void insertOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpSession session = httpRequest.getSession();
        List<Cart> allCartList = (List<Cart>)session.getAttribute("AllCartList");
        long currentTimeMillis = System.currentTimeMillis();
        Timestamp timestamp = new Timestamp(currentTimeMillis);
        out.println("Dad"+allCartList.size());
        double price = allCartList.get(0).getTotal_price();
        OrderService os = new OrderService();
        UserService us = new UserService();
        String userName = URLDecoder.decode((String) session.getAttribute("user"), "UTF-8");
        User user = us.findUser(userName);
        Order order = new Order("������",timestamp,price,user.getUserId());
        CartService cs = new CartService();
        cs.deleteCart(allCartList.get(0).getCart_id());
        cs.deleteCartItem(allCartList.get(0).getCart_id());
        int page = Integer.parseInt(request.getParameter("page"));
        os.addOrder(order);
        response.sendRedirect("/like/BookServlet?method=selectAllBook&"+page);
    }
    public void selectAllOrder(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
        // ������ѯ����ͼ����߼�
        // ...
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        OrderService oe = new OrderService();
        List<Order> list = oe.getAllOrders();

        request.getSession().setAttribute("AllOrderList", list);
        try{
            int page = Integer.parseInt(request.getParameter("page"));
            response.sendRedirect("bigwork/showorder.jsp?page="+page);
        }catch (Exception e){
            response.sendRedirect("bigwork/showorder.jsp");
        }
    }
}
