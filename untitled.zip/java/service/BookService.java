package service;
import bean.Book;
import dao.BookDao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class BookService {
    private BookDao bookDao;

    public BookService() {
        this.bookDao = new BookDao();
    }

    public void addBook(Book book) {
        bookDao.addBook(book);
    }

    public void deleteBook(int bookId) {
        bookDao.deleteBook(bookId);
    }

    public void updateBook(Book book) {
        bookDao.updateBook(book);
    }

    public Book findBook(int bookId){return bookDao.getBookById(bookId);}

    public List<Book> getAllBooks() {
        try {
            return bookDao.getAllBooks();
        } catch (Exception e) {
            e.printStackTrace();
            // 处理异常
            return Collections.emptyList();
        }
    }
}
