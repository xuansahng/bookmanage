package service;

import bean.Book;
import bean.User;
import dao.BookDao;
import dao.UserDao;

import java.util.Collections;
import java.util.List;

public class UserService {
    private UserDao userDao;

    public UserService() {
        this.userDao = new UserDao();
    }

    public void addUser(User user) {userDao.addUser(user);}

    public void deleteUser(int UserId) {
        userDao.deleteUser(UserId);
    }

    public void updateUser(User user) {
        userDao.updateUser(user);
    }

    public User findUser(String name){return userDao.getUserByName(name);}
    public User findUser(int id){return userDao.getUserById(id);}
    public List<User> getAllUsers() {
        try {
            return userDao.getAllUsers();
        } catch (Exception e) {
            e.printStackTrace();
            // �����쳣
            return Collections.emptyList();
        }
    }
}