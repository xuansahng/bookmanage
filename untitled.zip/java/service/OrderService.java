package service;

import bean.*;
import dao.OrderDao;
import dao.OrderItemDao;

import java.util.Collections;
import java.util.List;

public class OrderService {
    private OrderDao orderDao;
    private OrderItemDao orderItemDao;
    public OrderService(){
        this.orderDao = new OrderDao();
        this.orderItemDao = new OrderItemDao();
    }

    public void addOrder(Order order) {orderDao.addOrder(order);}
    public void deleteOrder(int orderId) {orderDao.deleteOrder(orderId);}
    public void updateOrder(Order order) {orderDao.updateOrder(order);}
    public Order findOrder(int orderId){return orderDao.getOrderById(orderId);}

    public void addOrderItem(OrderItem orderItem) {orderItemDao.addOrderItem(orderItem);}
    public void deleteOrderItem(int orderItemId) {orderItemDao.deleteOrderItem(orderItemId);}
    public void updateOrderItem(OrderItem orderItem) {orderItemDao.updateOrderItem(orderItem);}
    public OrderItem findOrderItem(int orderItemId) {return orderItemDao.getOrderItemById(orderItemId);}
    public List<Order> getAllOrders() {
        try {
            return orderDao.getAllOrders();
        } catch (Exception e) {
            e.printStackTrace();
            // �����쳣
            return Collections.emptyList();
        }
    }


}
