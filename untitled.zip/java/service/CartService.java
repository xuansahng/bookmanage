package service;

import bean.Book;
import bean.Cart;
import bean.CartItem;
import dao.CartDao;
import dao.CartItemDao;

import java.util.Collections;
import java.util.List;

public class CartService {
    private CartDao cartDao;
    private CartItemDao cartItemDao;

    public CartService() {
        this.cartDao = new CartDao();
        this.cartItemDao = new CartItemDao();
    }

    public void addCart(Cart cart) {cartDao.addCart(cart);}
    public void deleteCart(int cartId) {cartDao.deleteCart(cartId);}
    public void updateCart(Cart cart) {
        cartDao.updateCart(cart);
    }
    public Cart findCart(int cartId){return cartDao.getCartById(cartId);}

    public void addCartItem(CartItem cartItem) {cartItemDao.addCartItem(cartItem);}
    public void deleteCartItem(int cartItemId) {cartItemDao.deleteCartItem(cartItemId);}
    public void updateCartItem(CartItem cartItem) {cartItemDao.updateCartItem(cartItem);}
    public CartItem findCartItem(int cartItemId) {return cartItemDao.getCartItemById(cartItemId);}

    public List<Cart> getAllCarts() {
        try {
            return cartDao.getAllCarts();
        } catch (Exception e) {
            e.printStackTrace();
            // �����쳣
            return Collections.emptyList();
        }
    }

    public List<CartItem> getAllCartItems(int cartItemId) {
        try {
            return cartItemDao.getAllCartItems(cartItemId);
        } catch (Exception e) {
            e.printStackTrace();
            // �����쳣
            return Collections.emptyList();
        }
    }
}
