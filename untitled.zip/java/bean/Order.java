package bean;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class Order {

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }


    public Order(int order_id, String status, Timestamp timestamp, double price, int user_id) {
        this.order_id = order_id;
        this.status = status;
        this.timestamp = timestamp;
        this.price = price;
        this.user_id = user_id;
    }
    public Order( String status, Timestamp timestamp, double price, int user_id) {
        this.status = status;
        this.timestamp = timestamp;
        this.price = price;
        this.user_id = user_id;
    }


    private String status;
    private Timestamp timestamp;
    double price;

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    int user_id,order_id;

    public Order() {
    }

}
