package bean;

import java.io.Serializable;
import java.util.List;

public class Cart implements Serializable {

    public int getCart_id() {
        return cart_id;
    }

    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }

    public int getPurchase_quantity() {
        return purchase_quantity;
    }

    public void setPurchase_quantity(int purchase_quantity) {
        this.purchase_quantity = purchase_quantity;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public Cart(int cart_id, int purchase_quantity, int user_id, double total_price) {
        this.cart_id = cart_id;
        this.purchase_quantity = purchase_quantity;
        this.user_id = user_id;
        this.total_price = total_price;
    }

    private int cart_id,purchase_quantity,user_id;
    private double total_price;

    public List<String> getBook_name() {
        return book_name;
    }

    public void setBook_name(List<String> book_name) {
        this.book_name = book_name;
    }

    private List<String> book_name;

    public List<Integer> getBook_count() {
        return book_count;
    }


    public void setBook_count(List<Integer> book_count) {
        this.book_count = book_count;
    }

    public List<Double> getBook_tp() {
        return book_tp;
    }

    public void setBook_tp(List<Double> book_tp) {
        this.book_tp = book_tp;
    }

    private List<Integer> book_count;
    private List<Double> book_tp;

    public Cart() {
    }

}
