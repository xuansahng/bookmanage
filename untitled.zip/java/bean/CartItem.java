package bean;

public class CartItem {
    public int getCartitem_id() {
        return cartitem_id;
    }

    public void setCartitem_id(int cartitem_id) {
        this.cartitem_id = cartitem_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCart_id() {
        return cart_id;
    }

    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }
    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public CartItem(int quantity, int cart_id, int book_id, double total_price) {
        this.quantity = quantity;
        this.cart_id = cart_id;
        this.book_id = book_id;
        this.total_price = total_price;
    }
    public CartItem(int cartitem_id,int quantity, int cart_id, int book_id, double total_price) {
        this.cartitem_id=cartitem_id;
        this.quantity = quantity;
        this.cart_id = cart_id;
        this.book_id = book_id;
        this.total_price = total_price;
    }
    private int cartitem_id,quantity,cart_id,book_id;
    private double total_price;
    public CartItem() {
    }

}



