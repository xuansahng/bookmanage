package bean;

public class OrderItem {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }


    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public OrderItem(int id, int count, int book_id, double total_price, int order_id) {
        this.id = id;
        this.count = count;
        this.book_id = book_id;
        this.total_price = total_price;
        this.order_id = order_id;
    }

    private int id,count,book_id,order_id;
    private Double total_price;

    public OrderItem() {
    }

}

