package dao;

import bean.Book;
import bean.Cart;
import bean.CartItem;
import utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartItemDao {
    private Connection connection;

    public CartItemDao() {
        try {
            connection = JdbcUtils.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addCartItem(CartItem cartItem) {
        String sql = "INSERT INTO cartitem (cartitem_id,book_id, quantity,total_price,cart_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, cartItem.getCartitem_id());
            statement.setInt(2, cartItem.getBook_id());
            statement.setInt(3, cartItem.getQuantity());
            statement.setDouble(4, cartItem.getTotal_price());
            statement.setInt(5, cartItem.getCart_id());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCartItem(CartItem cartItem) {
        String sql = "UPDATE cartitem SET book_id=?,quantity=?,total_price=?,cart_id=? WHERE cartitem_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, cartItem.getBook_id());
            statement.setInt(2, cartItem.getQuantity());
            statement.setDouble(3, cartItem.getTotal_price());
            statement.setInt(4, cartItem.getCart_id());
            statement.setInt(5, cartItem.getCartitem_id());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCartItem(int id) {
        String sql = "DELETE FROM cartitem WHERE cart_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public CartItem getCartItemById(int id) {
        String sql = "SELECT * FROM cartitem WHERE cartitem_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractCartItemFromResultSet(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<CartItem> getAllCartItems(int cartId) {
        List<CartItem> cartItemsList = new ArrayList<>();
        String sql = "SELECT * FROM cartitem WHERE cart_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, cartId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                CartItem cartItem = extractCartItemFromResultSet(resultSet);
                cartItemsList.add(cartItem);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cartItemsList;
    }

    private CartItem extractCartItemFromResultSet(ResultSet resultSet) throws SQLException {
        int cartItemId = resultSet.getInt("cartitem_id");
        int bookId = resultSet.getInt("book_id");
        int quantity = resultSet.getInt("quantity");
        Double total_price = resultSet.getDouble("total_price");
        int cartId = resultSet.getInt("cart_id");
        return new CartItem(cartItemId,quantity,cartId,bookId,total_price);
    }
}
