package dao;

import bean.OrderItem;
import utils.JdbcUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderItemDao {
    private Connection connection;

    public OrderItemDao() {
        try {
            connection = JdbcUtils.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addOrderItem(OrderItem orderItem) {
        String sql = "INSERT INTO orderitem (book_id, count,total_price,order_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderItem.getBook_id());
            statement.setInt(2, orderItem.getCount());
            statement.setDouble(3, orderItem.getTotal_price());
            //statement.setString(4, orderItem.getOrder_id());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateOrderItem(OrderItem orderItem) {
        String sql = "UPDATE orderitem SET book_id=?,count=?,total_price=?,order_id=? WHERE orderitem_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderItem.getBook_id());
            statement.setInt(2, orderItem.getCount());
            statement.setDouble(3, orderItem.getTotal_price());
            //statement.setString(4, orderItem.getOrder_id());
            statement.setInt(5, orderItem.getId());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteOrderItem(int id) {
        String sql = "DELETE FROM orderitem WHERE orderitem_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public OrderItem getOrderItemById(int id) {
        String sql = "SELECT * FROM orderitem WHERE orderitem_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractOrderItemFromResultSet(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<OrderItem> getAllOrderItems(int orderId) {
        List<OrderItem> orderItemsList = new ArrayList<>();
        String sql = "SELECT * FROM orderitem WHERE order_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                OrderItem orderItem = extractOrderItemFromResultSet(resultSet);
                orderItemsList.add(orderItem);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItemsList;
    }

    private OrderItem extractOrderItemFromResultSet(ResultSet resultSet) throws SQLException {
        int id = resultSet.getInt("id");
        int bookId = resultSet.getInt("book_id");
        int count = resultSet.getInt("count");
        Double total_price = resultSet.getDouble("total_price");
        int orderId = resultSet.getInt("order_id");
        return new OrderItem(id,count,bookId,total_price,orderId);
    }
}
