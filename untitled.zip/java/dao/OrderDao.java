package dao;

import bean.Cart;
import bean.Order;
import utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDao {
    private Connection connection;

    public OrderDao() {
        try {
            connection = JdbcUtils.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addOrder(Order order) {
        String sql = "INSERT INTO orders (create_time, price,status,user_id) VALUES (?, ?, ?,?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, order.getTimestamp());
            statement.setDouble(2, order.getPrice());
            statement.setString(3, order.getStatus());
            statement.setInt(4, order.getUser_id());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateOrder(Order order) {
        String sql = "UPDATE `orders` SET create_time=?, price=?, status=? ,user_id=? WHERE order_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, order.getTimestamp());
            statement.setDouble(2, order.getPrice());
            statement.setString(3, order.getStatus());
            statement.setInt(4, order.getUser_id());
            //statement.setString(5, order.getOrder_id());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteOrder(int id) {
        String sql = "DELETE FROM orders WHERE order_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Order getOrderById(int order_id) {
        String sql = "SELECT * FROM orders WHERE order_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, order_id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractOrderFromResultSet(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<Order> getAllOrders() {
        List<Order> orderList = new ArrayList<>();
        String sql = "SELECT * FROM orders";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                System.out.println("���1");
                Order order = extractOrderFromResultSet(resultSet);
                orderList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("sda"+orderList.size());
        return orderList;
    }
    private Order extractOrderFromResultSet(ResultSet resultSet) throws SQLException {
        int oi = resultSet.getInt("order_id");
        Timestamp tt = resultSet.getTimestamp("create_time");
        Double pr = resultSet.getDouble("price");
        String st = resultSet.getString("status");
        int ui = resultSet.getInt("user_id");
        System.out.println(oi+"fd");
        return new Order(oi,st,tt,pr,ui);
    }
}
