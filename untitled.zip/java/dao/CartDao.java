package dao;

import bean.Book;
import bean.Cart;
import bean.CartItem;
import bean.User;
import service.BookService;
import service.UserService;
import utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDao {
    private Connection connection;

    public CartDao() {
        try {
            connection = JdbcUtils.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addCart(Cart cart) {
        String sql = "INSERT INTO cart (cart_id,purchase_quantity, total_price,user_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, cart.getCart_id());
            statement.setInt(2, cart.getPurchase_quantity());
            statement.setDouble(3, cart.getTotal_price());
            statement.setInt(4, cart.getUser_id());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCart(Cart cart) {
        String sql = "UPDATE cart SET purchase_quantity=?, total_price=?,user_id=? WHERE cart_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, cart.getPurchase_quantity());
            statement.setDouble(2, cart.getTotal_price());
            statement.setInt(3, cart.getUser_id());
            statement.setInt(4, cart.getCart_id());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCart(int id) {
        String sql = "DELETE FROM cart WHERE cart_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Cart getCartById(int user_id) {
        String sql = "SELECT * FROM cart WHERE user_id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, user_id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractCartFromResultSet(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public List<Cart> getAllCarts() {
        List<Cart> cartList = new ArrayList<>();
        String sql = "SELECT * FROM cart";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
               Cart cart = extractCartFromResultSet(resultSet);
                cartList.add(cart);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cartList;
    }
    private Cart extractCartFromResultSet(ResultSet resultSet) throws SQLException {
        int id = resultSet.getInt("cart_id");
        int pq = resultSet.getInt("purchase_quantity");
        Double tp = resultSet.getDouble("total_price");
        int uid = resultSet.getInt("user_id");
        return new Cart(id, pq,uid,tp);
    }
}
